// Keep track of the last update time and current tabs
let lastUpdateTime = 0;
let currentTabs = [];
const MIN_UPDATE_INTERVAL = 100; // 100ms between updates
let backgroundPort = null;
const tabsContainer = document.getElementById('tabs-container');

// Function to check if we should update the tabs list
function shouldUpdateTabs() {
    const now = Date.now();
    if (now - lastUpdateTime > MIN_UPDATE_INTERVAL) {
        lastUpdateTime = now;
        return true;
    }
    return false;
}

// Function to escape HTML to prevent XSS
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Function to render tabs
function renderTabs(mediaTabs) {
    if (!tabsContainer) return;
    
    if (mediaTabs && mediaTabs.length > 0) {
        tabsContainer.innerHTML = '';
        mediaTabs.forEach(tab => {
            const tabItem = document.createElement('div');
            tabItem.className = 'tab-item';
            tabItem.innerHTML = `
                <div class="tab-content">
                    <div class="tab-title">${escapeHtml(tab.title)}</div>
                    <div class="tab-url">${escapeHtml(tab.url)}</div>
                </div>
                <div class="tab-controls">
                    <button class="control-button prev-btn" data-tab-id="${tab.id}" title="Previous Track"></button>
                    <button class="control-button pause-btn" data-tab-id="${tab.id}">${tab.isPlaying ? 'Pause' : 'Play'}</button>
                    <button class="control-button next-btn" data-tab-id="${tab.id}" title="Next Track"></button>
                    <button class="control-button mute-btn" data-tab-id="${tab.id}">${tab.muted ? 'Unmute' : 'Mute'}</button>
                </div>
            `;

            const tabContent = tabItem.querySelector('.tab-content');
            tabContent.addEventListener('click', () => {
                browser.tabs.update(tab.id, { active: true });
                window.close();
            });

            const prevBtn = tabItem.querySelector('.prev-btn');
            const pauseBtn = tabItem.querySelector('.pause-btn');
            const nextBtn = tabItem.querySelector('.next-btn');
            const muteBtn = tabItem.querySelector('.mute-btn');

            prevBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                await skipTrack(tab.id, 'prev', prevBtn);
            });

            pauseBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                await toggleTabPlayPause(tab.id, pauseBtn);
            });

            nextBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                await skipTrack(tab.id, 'next', nextBtn);
            });

            muteBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                await toggleTabMute(tab.id, muteBtn);
            });

            tabsContainer.appendChild(tabItem);
        });
    } else {
        tabsContainer.innerHTML = '<div class="no-tabs">🔇 No tabs with media found</div>';
    }
}

// Function to update tabs list with new data
function updateTabs(tabs) {
    if (!tabs || !Array.isArray(tabs)) return;
    currentTabs = tabs;
    renderTabs(currentTabs);
}

// Connect to background script
function connectToBackground() {
    if (backgroundPort) {
        return;
    }
    
    try {
        backgroundPort = browser.runtime.connect({ name: 'popup' });
        
        backgroundPort.onMessage.addListener((message) => {
            if (message.command === 'update_media_tabs' && message.tabs) {
                // Update our local state with the latest tab information
                if (message.tabs && Array.isArray(message.tabs)) {
                    // Update the currentTabs array with the new state
                    currentTabs = message.tabs.map(tab => ({
                        ...tab,
                        // Ensure we have all required properties
                        isPlaying: tab.isPlaying || tab.audible,
                        muted: tab.muted || false
                    }));
                    
                    // Re-render the tabs with the updated state
                    renderTabs(currentTabs);
                }
            }
        });
        
        backgroundPort.onDisconnect.addListener(() => {
            backgroundPort = null;
        });
    } catch (error) {
        console.error('Error connecting to background:', error);
        backgroundPort = null;
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const tabsContainer = document.getElementById('tabs-container');
    
    // Connect to background script
    connectToBackground();
    
    // Add visibility change listener to refresh when popup is reopened
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            updateTabsList();
            // Reconnect if needed
            if (!backgroundPort) {
                connectToBackground();
            }
        }
    });

    function renderTabs(mediaTabs) {
        if (mediaTabs && mediaTabs.length > 0) {
            tabsContainer.innerHTML = '';
            mediaTabs.forEach(tab => {
                const tabItem = document.createElement('div');
                tabItem.className = 'tab-item';
                tabItem.innerHTML = `
                    <div class="tab-content">
                        <div class="tab-title">${escapeHtml(tab.title)}</div>
                        <div class="tab-url">${escapeHtml(tab.url)}</div>
                    </div>
                    <div class="tab-controls">
                        <div class="tab-info"></div>
                        <button class="control-button prev-btn" data-tab-id="${tab.id}" title="Previous Track"></button>
                        <button class="control-button pause-btn" data-tab-id="${tab.id}"> Pause</button>
                        <button class="control-button next-btn" data-tab-id="${tab.id}" title="Next Track"></button>
                        <button class="control-button mute-btn" data-tab-id="${tab.id}"> Mute</button>
                    </div>
                `;

                const tabContent = tabItem.querySelector('.tab-content');
                tabContent.addEventListener('click', () => {
                    browser.tabs.update(tab.id, { active: true });
                    window.close();
                });

                const prevBtn = tabItem.querySelector('.prev-btn');
                const pauseBtn = tabItem.querySelector('.pause-btn');
                const nextBtn = tabItem.querySelector('.next-btn');
                const muteBtn = tabItem.querySelector('.mute-btn');

                pauseBtn.textContent = tab.isPlaying ? ' Pause' : ' Play';
                muteBtn.textContent = tab.muted ? 'Unmute' : ' Mute';

                prevBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await skipTrack(tab.id, 'prev', prevBtn);
                });
                pauseBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await toggleTabPlayPause(tab.id, pauseBtn);
                });
                nextBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await skipTrack(tab.id, 'next', nextBtn);
                });
                muteBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await toggleTabMute(tab.id, muteBtn);
                });

                tabsContainer.appendChild(tabItem);
            });
        } else {
            tabsContainer.innerHTML = '<div class="no-tabs">🔇 No tabs with media found</div>';
        }
    }

    // Function to update the tabs list
    async function updateTabsList() {
        if (!shouldUpdateTabs()) return;
        
        try {
            // If we have a connection, the background will push updates to us
            // Otherwise, fall back to the old method
            if (!backgroundPort) {
                const response = await browser.runtime.sendMessage({ command: 'get_media_tabs' });
                if (response && response.tabs) {
                    updateTabs(response.tabs);
                }
            } else {
                // Request an immediate update
                backgroundPort.postMessage({ command: 'request_update' });
            }
        } catch (error) {
            console.error('Error updating tabs list:', error);
            // Try to reconnect if we get an error
            if (error.message.includes("disconnected")) {
                backgroundPort = null;
                connectToBackground();
            }
        }
    }

    try {
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Timeout')), 5000);
        });
        const mediaTabs = await Promise.race([
            browser.runtime.sendMessage({ command: 'get_media_tabs' }),
            timeoutPromise,
        ]);
        renderTabs(mediaTabs);
    } catch (error) {
        console.error('Popup: initial load error', error);
        if (error.message === 'Timeout') {
            tabsContainer.innerHTML = '<div class="no-tabs">⏰ Loading timeout - try refreshing</div>';
        } else {
            tabsContainer.innerHTML = '<div class="no-tabs">❌ Error loading tabs</div>';
        }
    }

    // Listen for push updates from background
    browser.runtime.onMessage.addListener((message) => {
        if (message && message.command === 'audible_tabs_changed') {
            // Adapt pushed schema to popup schema
            const tabs = (message.tabs || []).map(t => ({
                id: t.id,
                title: t.title,
                url: t.url,
                muted: !!t.muted,
                isPlaying: true,
                isPaused: false,
                mediaCount: 1,
            }));
            renderTabs(tabs);
        }
    });
});

// Helper function to escape HTML characters
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Function to toggle play/pause for a tab
async function toggleTabPlayPause(tabId, button) {
    try {
        console.log(`Popup: Toggling play/pause for tab ${tabId}`);
        
        // Disable button temporarily to prevent multiple clicks
        button.disabled = true;
        button.textContent = '⏳ Loading...';
        
        const result = await browser.runtime.sendMessage({ 
            command: "toggle_play_pause", 
            tabId: tabId 
        });
        
        if (result.success) {
            // Update button text based on new state
            button.textContent = result.isPlaying ? 'Pause' : 'Play';
            console.log(`Popup: Tab ${tabId} is now ${result.isPlaying ? 'playing' : 'paused'}`);
        } else {
            console.error(`Popup: Failed to toggle play/pause for tab ${tabId}:`, result.error);
            button.textContent = '❌ Error';
        }
    } catch (error) {
        console.error(`Popup: Error toggling play/pause for tab ${tabId}:`, error);
        button.textContent = '❌ Error';
    } finally {
        // Re-enable button after a short delay
        setTimeout(() => {
            button.disabled = false;
        }, 1000);
    }
}

// Function to skip to previous/next track in a tab
async function skipTrack(tabId, direction, button) {
    try {
        console.log(`Popup: Skipping ${direction} track for tab ${tabId}`);
        
        // Disable button temporarily to prevent multiple clicks
        button.disabled = true;
        button.textContent = '⏳';
        
        const result = await browser.runtime.sendMessage({ 
            command: "skip_track", 
            tabId: tabId,
            direction: direction
        });
        
        if (result.success) {
            console.log(`Popup: Successfully skipped ${direction} track in tab ${tabId}`);
            // Visual feedback
            button.textContent = direction === 'prev' ? '' : '';
        } else {
            console.error(`Popup: Failed to skip ${direction} track in tab ${tabId}:`, result.error);
            button.textContent = '❌';
        }
    } catch (error) {
        console.error(`Popup: Error skipping ${direction} track in tab ${tabId}:`, error);
        button.textContent = '❌';
    } finally {
        // Re-enable button after a short delay
        setTimeout(() => {
            button.disabled = false;
            button.textContent = direction === 'prev' ? '' : '';
        }, 1000);
    }
}

// Function to toggle mute for a tab
async function toggleTabMute(tabId, button) {
    try {
        console.log(`Popup: Toggling mute for tab ${tabId}`);
        
        // Disable button temporarily to prevent multiple clicks
        button.disabled = true;
        button.textContent = '⏳ Loading...';
        
        const result = await browser.runtime.sendMessage({ 
            command: "toggle_mute", 
            tabId: tabId 
        });
        
        if (result.success) {
            // Update button text based on new state
            button.textContent = result.isMuted ? 'Unmute' : 'Mute';
            console.log(`Popup: Tab ${tabId} is now ${result.isMuted ? 'muted' : 'unmuted'}`);
        } else {
            console.error(`Popup: Failed to toggle mute for tab ${tabId}:`, result.error);
            button.textContent = '❌ Error';
        }
    } catch (error) {
        console.error(`Popup: Error toggling mute for tab ${tabId}:`, error);
        button.textContent = '❌ Error';
    } finally {
        // Re-enable button after a short delay
        setTimeout(() => {
            button.disabled = false;
        }, 1000);
    }
}